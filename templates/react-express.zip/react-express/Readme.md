Hello All,
To use the downloaded template, you need to have docker installed on your computer.
If you do not have docker and docker-compose installed on your computer you may use
<https://docs.docker.com/engine/install/>


# How To make build
```cd <Project_Dir>```

```docker-compose build```

Open your command terminal, and change your directory to the folder containing the files.
# How to run the application
```docker-compose up```

# How to stop the application
```docker-compse stop``` or ```CTRL+C```
