import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function Message() {
    const [result, setResult] = useState(null);
    const message = async () => {
        try{
            let res = await axios.get("/api");
            let result = res.data.message;
            setResult(result);
        } catch(e) {
            console.log(e)
        }
    };

    useEffect(() => {
        message()
    },[])
    
    return (
        <div>
            {result}
        </div>
    )
}