from flask import Flask
from flask_cors import CORS

app = Flask(__name__)

CORS(app)

# end point for hello world
@app.route("/api", methods = ["GET"])
def index():
    return {"message": "Hello World !!! I am coming from Flask"}


if __name__ == "__main__":
    app.run(debug=True, host = "0.0.0.0", port=5000)